﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using static PrismTemp.Utilities.Variables;
using static PrismTemp.Utilities.ColorLib;
using static PrismTemp.Mods.Categories.Settings;
using static PrismTemp.Menu.Main;
using Photon.Pun;
using Object = UnityEngine.Object;
using System.Linq;
using Photon.Realtime;
using UnityEngine.InputSystem.Controls;
using System.Drawing;
using System.Xml.Linq;
using PrismTemp.Utilities;


namespace PrismTemp.Mods.Categories
{
    public class Visuals 
    {
        
    }
}


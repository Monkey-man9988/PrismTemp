﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using UnityEngine.InputSystem;
using UnityEngine;
using Object = UnityEngine.Object;
using static PrismTemp.Utilities.ColorLib;
using static PrismTemp.Utilities.Variables;
using static PrismTemp.Menu.Main;
using static PrismTemp.Menu.ButtonHandler;
using static PrismTemp.Menu.Optimizations;
using PrismTemp.Utilities;
using PrismTemp.Menu;
using static PrismTemp.Mods.Categories.Move;
using static PrismTemp.Utilities.Patches.OtherPatches;
using static PrismTemp.Utilities.GunTemplate;
using System.Linq;
using Oculus.Platform;
using Photon.Pun;

namespace PrismTemp.Mods.Categories
{
    public class Settings
    {
        public static void SwitchHands(bool setActive)
        {
            rightHandedMenu = setActive;
        }

        public static void ClearNotifications()
        {
            NotificationLib.ClearAllNotifications();
        }

        public static void ToggleNotifications(bool setActive)
        {
            toggleNotifications = setActive;
        }

        public static void ToggleDisconnectButton(bool setActive)
        {
            toggledisconnectButton = setActive;
        }
        public static void GunExample()
        {
            GunTemplate.StartBothGuns(() =>
            {// method when active

            }, false); // lockon
            {// method when not active

            }
        }
        public static void Discord()
        {
            UnityEngine.Application.OpenURL("REPLACE THIS WITH YOUR LINK");
        }

    }
}

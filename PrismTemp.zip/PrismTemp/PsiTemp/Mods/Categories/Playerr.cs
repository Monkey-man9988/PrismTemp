﻿using System;
using System.Collections.Generic;
using System.Text;
using static PrismTemp.Utilities.GunTemplate;
using static PrismTemp.Utilities.ColorLib;
using static PrismTemp.Utilities.Variables;
using static PrismTemp.Menu.Main;
using static PrismTemp.Mods.Categories.Settings;
using UnityEngine;
using UnityEngine.InputSystem;
using PrismTemp.Utilities;
using UnityEngine.XR;
using UnityEngine.Animations.Rigging;
using UnityEngine.XR.Interaction.Toolkit;
using GorillaNetworking;
using PrismTemp.Utilities.Patches;
using PrismTemp.Menu;
using ExitGames.Client.Photon;
using Photon.Pun;
using Photon.Realtime;
using HarmonyLib;
using BepInEx;
using PrismTemp.Utilities;

namespace PrismTemp.Mods.Categories
{
    public class Playerr
    {
       
    }
}

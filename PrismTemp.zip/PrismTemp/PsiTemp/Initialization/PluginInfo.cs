﻿namespace PrismTemp.Initialization
{
    public class PluginInfo
    {
        public const string menuGUID = "com.Prism.PrismTemp.org";
        public const string menuName = "Prism Temp";
        public const string menuVersion = "1.0";
    }
}
